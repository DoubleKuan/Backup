<?php
namespace app\admin\controller;

class Xml extends Common
{
    public function index()
    {
        return $this->fetch();
    }
}
